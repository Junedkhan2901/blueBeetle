import logo from './logo.svg';
import './App.css';
import Ablog from './components/componentA';
import Bblog from './components/componentB';

function App() {
  return (
    
    <div >
      <Ablog />
      <Bblog />
    </div>
  );
}

export default App;
